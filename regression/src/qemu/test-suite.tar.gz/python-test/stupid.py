#!/usr/bin/env python3

print("This line is printed from the stupid.py")

